<?php

//recebe dados do formulario e faz os calculos

$ip1  = $_GET['ip1'];
$ip2  = $_GET['ip2'];
$ip3  = $_GET['ip3'];
$ip4  = $_GET['ip4'];
$masc = $_GET['masc'];

//$ip1 = 192;
//$ip2  = 165;
//$ip3  = 10;
//$ip4 = 105;
//$masc = 29;

$bits = 32 - $masc;

$ipsPorRede = pow(2, $bits); /*quanto a gente vai somar */

$subredes = 256/$ipsPorRede; /*QNTS VEZES A GENTE VAI PRECISAR SOMAR*/

$rede = (int)($ip4/$ipsPorRede);

$enderecoRede = $rede*$ipsPorRede;

$firstIP = $rede*$ipsPorRede + 1;

$broad = $enderecoRede+$ipsPorRede - 1;

$lastIP = $broad - 1;

$mascDecimal = 256 - $ipsPorRede;

function classeIP ($ip1)
{
    if ($ip1 <= 127) {
        return $classeIP = "A";
    } elseif ($ip1 <= 191) {
        return $classeIP = "B";
    } elseif ($ip1 <= 223) {
        return $classeIP = "C";
    } elseif ($ip1 <= 239) {
        return $classeIP = "D";
    } else {
        return $classeIP = "E";
    }
}

function privadoIP ($ip1,$ip2,$ip3){
    if ($ip1 == 172 and $ip2>=16 and $ip2<=31 ) {
        return $privadoIP = "Não";
    } elseif ($ip1 == 10 and $ip2>=0 and $ip2<=255) {
        return $privadoIP = "Não";
    } elseif ($ip1 == 192 and $ip2==168 and $ip3>=0 and $ip3<=255) {
        return $privadoIP = "Não";
  }else{
    return $privadoIP = "Sim";

  }
}

$classe = classeIP($ip1);
$privado = privadoIP($ip1,$ip2,$ip3);

/* CONDICIONA QUANTOS NÚMEROS PARA A SEQUENCIA*/

/*ENDEREÇO DE REDE DE CADA SUB-REDE*/

echo "
<table class='ui celled table'>
  <thead>
    <tr><th>IPs por rede:</th>
    <th>Sub-redes:</th>
    <th>Classe:</th>
    <th>Público?</th>
    <th>Máscara:</th>

  </tr></thead>
  <tbody>

    <tr>
        <td <li> {$ipsPorRede}</li></td>
        <td <li> {$subredes}</li></td>
        <td <li> {$classe}</li></td>
        <td <li> {$privado}</li></td>
        <td <li> 255.255.255.{$mascDecimal}</li></td>

    </tr>
   
  </tbody>
</table>
";


    $result=0;
    for ($i=0; $i<$subredes ; $i++) {
      $rede_end= $result;
      $primeiro_IP= $result + 1;
      $guard=$result + $ipsPorRede;
      $result= $guard;
      $broad_sub=$result-1;
      $ultimo_IP=$broad_sub - 1;

      if($ip4<=$broad_sub and $ip4>=$rede_end){
        echo"O IP informado com a máscara {$masc} esta na sub-rede:{$i}";
      }
      echo "

      <table class='ui definition table'>
  <thead>
    <tr><th></th>
    <th>Endereço de rede:</th>
    <th>Broadcast:</th>
    <th>Primeiro IP:</th>
    <th> Último IP:</th>
  </tr></thead>
  <tbody>

    <tr>
      <td>Sub-rede {$i}</td>
        <td <li> {$rede_end}</li></td>
        <td <li> {$broad_sub}</li></td>
        <td <li> {$primeiro_IP}</li></td>
        <td <li> {$ultimo_IP}</li></td>
    </tr>
    
</tbody></table> ";
    }

/*ENDEREÇO DE BROADCAST DE CADA SUB-REDE*/


/*
echo "

<table class='ui definition table'>
  <thead>
    <tr><th></th>
    <th>Endereço de rede:</th>
    <th>Broadcast:</th>
    <th>Primeiro IP:</th>
    <th> Último IP:</th>
  </tr></thead>
  <tbody>
    <tr>
      <td>Sub-rede 1</td>
        <td <li> {$enderecoRede}</li></td>
        <td <li> {$broad}</li></td>
        <td <li> {$firstIP}</li></td>
        <td <li> {$lastIP}</li></td>
    </tr>
    
</tbody></table>

"; */
