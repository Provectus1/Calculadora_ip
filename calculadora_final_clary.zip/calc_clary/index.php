
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="css/Semantic/semantic.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
        
        $(document).ready(function () {
            $("#bt").click(function () {
               var vip1  = $("#ip1").val();
               var vip2  = $("#ip2").val();
               var vip3  = $("#ip3").val();
               var vip4  = $("#ip4").val();
               var vmasc = $("#masc").val();

               $.get("continhas.php",
                   {
                       ip1 : vip1, ip2 : vip2, ip3 : vip3, ip4 : vip4, masc : vmasc
                   },function (resultado) {
                      $(".resposta").html(resultado);
                   } );
                   
            });

        });


    </script>




</head>
<!--<body>

    <h1 class="h1" align="center"> CALCULADORA IP </h1>


    <h3 class="h3" align="center">Digite o IP e a Máscara</h3>

    <div class="ui large  form">
        <div class="inline fields">
            <div class="one wide field">
                <input type="text" id="ip1"> <p>.</p>
            </div>
            <div class="one wide field">
                <input type="text" id="ip2"> <p>.</p>
            </div>
            <div class="one wide field">
                <input type="text" id="ip3"> <p>.</p>
            </div>
            <div class="one wide field">
                <input type="text" id="ip4"> <p>/</p>
            </div>
            <div class="one wide field">
                <input type="number" id="masc" min="24" max="32">
            </div>

            <button class="ui olive button" id="bt" >Enviar</button>

        </div>

    </div>

    <div class="resposta">

    </div>


</body>
</html>


--> 
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

  <!-- Site Properties -->
  <title>Login Example - Semantic</title>
 
  <style type="text/css">
    body {
      background-color: #DADADA;
    }
    body > .grid {
      height: 100%;
    }
    .image {
      margin-top: -100px;
    }
    .column {
      max-width: 450px;
    }
  </style>
  <script>
  $(document)
    .ready(function() {
      $('.ui.form')
        .form({
          fields: {
            email: {
              identifier  : 'email',
              rules: [
                {
                  type   : 'empty',
                  prompt : 'Please enter your e-mail'
                },
                {
                  type   : 'email',
                  prompt : 'Please enter a valid e-mail'
                }
              ]
            },
            password: {
              identifier  : 'password',
              rules: [
                {
                  type   : 'empty',
                  prompt : 'Please enter your password'
                },
                {
                  type   : 'length[6]',
                  prompt : 'Your password must be at least 6 characters'
                }
              ]
            }
          }
        })
      ;
    })
  ;
  </script>
</head>
<body>

<div class="ui middle aligned center aligned grid">
  <div class="column">
    <h2 class="ui teal image header">
      <img src="calculator.png" class="image">
      <div class="content">
        CALCULADORA IP - 3INFO3
      </div>
    </h2>
    <div class="ui large  form">
      <div class="ui stacked segment">
          <label  style="color: #fa980b;"> Digite seu ip</label>
           
           <div class="inline fields">
            <div class="four wide field" style="width: 15%;">
                <input type="text" id="ip1"> <p>.</p>
            </div>
            <div class="four wide field">
                <input type="text" id="ip2"> <p>.</p>
            </div>
            <div class="four wide field">
                <input type="text" id="ip3"> <p>.</p>
            </div>
            <div class="four wide field">
                <input type="text" id="ip4"> 
            </div>
            


        </div>
        <div class="field">
          <label  style="color: #fa980b;"> Digite a máscara</label>


        <div class="inline fields">
          <div class="eight wide field" style="color: white;"> .</div>
            
          <div class="five wide field">
                <input type="number" id="masc" min="24" max="32" placeholder="/">
          </div>

          <div class="seven wide field" style="color: white;"> .</div>
        </div>
        <button class="ui fluid large button" style="background: #fa980b;" id="bt" >Calcular</button>

        <!--<input type="submit" style="background: #fa980b;" class="ui fluid large submit button" value="Calcular" >--> 
        </div>
      </div>


    </form>

  </div>
    <div class="resposta">
</div>

</body>

</html>
