<?php

//recebe dados do formulario e faz os calculos

$ip1  = $_GET['ip1'];
$ip2  = $_GET['ip2'];
$ip3  = $_GET['ip3'];
$ip4  = $_GET['ip4'];
$masc = $_GET['masc'];

//$ip1 = 192;
//$ip2  = 165;
//$ip3  = 10;
//$ip4 = 105;
//$masc = 29;

$bits = 32 - $masc;

$ipsPorRede = pow(2, $bits);

$subredes = 256/$ipsPorRede;

$rede = (int)($ip4/$ipsPorRede);

$enderecoRede = $rede*$ipsPorRede;

$firstIP = $rede*$ipsPorRede + 1;

$broad = $enderecoRede+$ipsPorRede - 1;

$lastIP = $broad - 1;

$mascDecimal = 256 - $ipsPorRede;

function classeIP ($ip1)
{
    if ($ip1 <= 127) {
        return $classeIP = "A";
    } elseif ($ip1 <= 191) {
        return $classeIP = "B";
    } elseif ($ip1 <= 223) {
        return $classeIP = "C";
    } elseif ($ip1 <= 239) {
        return $classeIP = "D";
    } else {
        return $classeIP = "E";
    }
}

$classe = classeIP($ip1);

/*
echo "<li>IPs por rede: {$ipsPorRede}</li>";
echo "<li>Sub-redes: {$subredes}</li>";
echo "<li>Rede: {$rede}</li>";
echo "<li>Endereço de rede: {$enderecoRede}</li>";
echo "<li>Broadcast: {$broad}</li>";
echo "<li>Primeiro IP: {$firstIP}</li>";
echo "<li>Último IP: {$lastIP}</li>";
echo "<li>Máscara: 255.255.255.{$mascDecimal}</li>";
echo "<li>Classe: {$classe}</li>";
*/

/*
echo "
<table class='ui celled table'>
  <thead>
    <tr><th>IPs por rede:</th>
    <th>Sub-redes:</th>
    <th>Rede</th>
    <th>Endereço de rede:</th>
    <th>Broadcast:</th>
    <th>Primeiro IP:</th>
    <th> Último IP:</th>
    <th>Máscara:</th>
    <th>Classe:</th>
    <th>Público?</th>

  </tr></thead>
  <tbody>

    <tr>
        <td <li> {$ipsPorRede}</li></td>
        <td <li> {$subredes}</li></td>
        <td <li> {$rede}</li></td>
        <td <li> {$enderecoRede}</li></td>
        <td <li> {$broad}</li></td>
        <td <li> {$firstIP}</li></td>
        <td <li> {$lastIP}</li></td>
        <td <li> 255.255.255.{$mascDecimal}</li></td>
        <td <li> {$classe}</li></td>
        <td <li> {$publi_priv}</li></td>
    </tr>
   
  </tbody>
</table>
";
*/


echo "
<table class='ui celled table'>
  <thead>
    <tr><th>IPs por rede:</th>
    <th>Sub-redes:</th>
    <th>Classe:</th>
    <th>Público?</th>

  </tr></thead>
  <tbody>

    <tr>
        <td <li> {$ipsPorRede}</li></td>
        <td <li> {$subredes}</li></td>
        <td <li> {$classe}</li></td>
        <td <li> {$publi_priv}</li></td>
    </tr>
   
  </tbody>
</table>
";

echo "

<table class='ui definition table'>
  <thead>
    <tr><th></th>
    <th>Rede</th>
    <th>Endereço de rede:</th>
    <th>Broadcast:</th>
    <th>Primeiro IP:</th>
    <th> Último IP:</th>
    <th>Máscara:</th>
  </tr></thead>
  <tbody>
    <tr>
      <td>Sub-rede 1</td>
        <td <li> {$rede}</li></td>
        <td <li> {$enderecoRede}</li></td>
        <td <li> {$broad}</li></td>
        <td <li> {$firstIP}</li></td>
        <td <li> {$lastIP}</li></td>
        <td <li> 255.255.255.{$mascDecimal}</li></td>
    </tr>
    <tr>
      <td>Sub-rede 2</td>
      <td>rating (integer)</td>
      <td>Sets the current star rating to specified value</td>
    </tr>
</tbody></table>

";